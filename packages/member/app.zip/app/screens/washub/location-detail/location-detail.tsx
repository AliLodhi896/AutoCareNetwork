import React, { FC, useEffect, useState } from "react";
import { StackScreenProps } from "@react-navigation/stack";
import { HomeNavigatorParamList } from "../home/home-stack";
import { Layout } from "../../../components/washub/layout";
import RedeemContainer from "../../../components/washub/redeem-container";
import { ScrollView, TouchableOpacity, View } from "react-native";
import { styles } from "./location-detail.styles";
import { LocationDetails } from "../../../components/washub/location-details/location-details";
import { LocationActions } from "../../../components/washub/location-details/location-actions";
import { CircleActionButton } from "../../../components/washub/circle-action-button/circle-action-button";
import { useAppState } from "../../../context/app-state-context";
import HasFreeWash from "../has-free-wash/has-free-wash";
import analytics from '@react-native-firebase/analytics';

const LocationDetailScreen: FC<
  StackScreenProps<HomeNavigatorParamList, "locationDetail">
> = ({ navigation, route }) => {
  const { appState } = useAppState();
  const [showFreeInfo, setShowFreeInfo] = useState<boolean>(false);
  const station = route.params.station;

  useEffect(() => {
    return () => {
      setShowFreeInfo(false);
    };
  }, []);

  const redeemWash = () => {
    if (appState.selectedCard.CanWashToday) {
      navigation.navigate("redeemCarWash", { station: station });
      return;
    }
    setShowFreeInfo(true);
  };

console.log('station',station)
  const WashPlansDetailsAnalytics = async () => {
    try {
        await analytics().logEvent('view_item', {
          item_list_id: 'wash_details',
          item_list_name: 'Wash Details',
          item_brand: station?.LocationName,
          item_name: station?.ServiceLevel,
          item_id: station?.LocationId,
          item_category: 'car wash',
          location_id: station?.LocationGooglePlacesId,
          affiliation: '*Pitch Deck - 222560201',
        });
    } catch (error) {
      console.error('Error logging event:', error);
    }
  }

  useEffect(() => {
    WashPlansDetailsAnalytics()
  }, [station])

  const isPremiumOnly = true;
  const containerStyle = (isPremiumOnly) ? styles.premiumContainer : styles.container;
  return (
    <Layout>
      <RedeemContainer showBack={!showFreeInfo}>
        {showFreeInfo ? (
          <HasFreeWash handleClose={() => setShowFreeInfo(false)} />
        ) : (
          <View style={containerStyle}>
            <ScrollView>
              <LocationDetails location={station} isPremiumOnly={isPremiumOnly} />
            </ScrollView>
            <LocationActions location={station} />
            <CircleActionButton
              style={styles.redeemButton}
              textStyle={styles.redeemButtonText}
              text={"REDEEM WASH"}
              onPress={() => {
                redeemWash();
              }}
            />
          </View>
        )}
      </RedeemContainer>
    </Layout>
  );
};

export default LocationDetailScreen;
