import { StyleSheet } from "react-native";
import { normalize } from "../../../../../shared/utils/normalize";
import { isAndroidFontLargest } from "../../../utils/common";

export const styles = StyleSheet.create({
  container: {
    flexDirection: "column",
    borderRadius: normalize(8),
    borderColor: "#1B588A",
    borderWidth: 5,
    backgroundColor: "#ffffff",
    alignSelf: "stretch",
    flex: 1,
    justifyContent: "space-between",
  },
  premiumContainer: {
    flexDirection: "column",
    borderRadius: normalize(8),
    borderWidth: 5,
    backgroundColor: "#ffffff",
    alignSelf: "stretch",
    flex: 1,
    justifyContent: "space-between",
    borderColor: "#FF0000",
  },
  redeemButton: {
    alignSelf: "center",
    width: normalize(isAndroidFontLargest() ? 72 : 68),
    height: normalize(isAndroidFontLargest() ? 72 : 68),
    position: "absolute",
    bottom: normalize(-30),
  },
  redeemButtonText: {
    fontSize: normalize(isAndroidFontLargest() ? 11 : 13),
  },
  payNowButtonText: {
    fontSize: normalize(isAndroidFontLargest() ? 14 : 18),
  },
});
