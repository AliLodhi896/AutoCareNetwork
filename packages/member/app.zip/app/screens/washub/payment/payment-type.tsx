import React, { FC, useEffect, useState } from "react";
import { StackScreenProps } from "@react-navigation/stack";
import { HomeNavigatorParamList } from "../home/home-stack";
import RedeemContainer from "../../../components/washub/redeem-container";
import { View, Text, ScrollView, Platform } from "react-native";
import { useAppState } from "../../../context/app-state-context";
import HasFreeWash from "../has-free-wash/has-free-wash";
import { styles } from "./payment-type.styles";
import { Button, WashubInput } from "../../../../../shared/components";
import { Field } from "formik";
import AppFormField from "../../../components/washub/form/AppFormField";
import PaymenInput from "../../../components/washub/payment-input/paymen-input";
import { StripeProvider, useStripe } from '@stripe/stripe-react-native';
import WashubClient from "../../../services/api/api";

const PaymentType: FC<
  StackScreenProps<HomeNavigatorParamList, "locationDetail">
> = ({ navigation, route }) => {
  const { selectedPlan, station } = route.params
  const { appState } = useAppState();
  const [showFreeInfo, setShowFreeInfo] = useState<boolean>(false);
  const { initPaymentSheet, presentPaymentSheet } = useStripe();
  const [loading, setLoading] = useState(false);
  const cardCode = appState?.selectedCard?.CardCode
  const stationId = station?.LocationId


  useEffect(() => {
    return () => {
      setShowFreeInfo(false);
    };
  }, []);


  const initializePaymentSheet = async () => {
    const { error } = await initPaymentSheet({
      merchantDisplayName: "Autocare Network",
      intentConfiguration: {
        mode: {
          amount: 1099,
          currencyCode: 'USD',
        },
      }
    });
    if (error) {
      // handle error
    }
  };


  const didTapCheckoutButton = async () => {
    const { error } = await presentPaymentSheet();

    if (error) {
      if (error.code) {
        // Customer canceled - you should probably do nothing.
      } else {
        // PaymentSheet encountered an unrecoverable error. You can display the error to the user, log it, etc.
      }
    } else {
      // Payment completed - show a confirmation screen.
    }
  }

  const createWash = async () => {
    setLoading(true);
    const { error, result } = await WashubClient.createPendingWash(cardCode, stationId);
    console.log('asdasasdadasd', result,error)
    setLoading(false);
  }


  return (
    <ScrollView showsVerticalScrollIndicator={false} style={{ flex: 1, backgroundColor: "#FFFFFF", padding: 20 }}>
      <RedeemContainer showBack={!showFreeInfo}>
        {showFreeInfo ? (
          <HasFreeWash handleClose={() => setShowFreeInfo(false)} />
        ) : (
          <StripeProvider
            publishableKey="pk_test_51KK27UB6yjqN0OelyLhDTqF7dO3wSeCusagtyTullpN4asaYObocmDHeE5Ph1QAjIxagS7fyAhtKaq4XrJgyMbn300PLF7hsuE"
          >
            <ScrollView style={styles.container}>
              <Text style={styles.title}>{selectedPlan?.StationServiceName}</Text>
              <Text style={styles.text}> ${selectedPlan?.StationServicePrice}</Text>
              <>
                <Button
                  style={{
                    backgroundColor: "#000",
                    borderRadius: 8,
                    marginTop: 40,
                  }}
                  disabled={true}
                  preset="primary"
                  text={"Apple Pay"}
                />
                <View style={styles.helperTextContainer}>
                  <View
                    style={{
                      padding: 1,
                      backgroundColor: "#666666",
                      width: "30%",
                      height: 1,
                    }}
                  ></View>
                  <Text style={styles.helperText}> Or Pay with Card</Text>
                  <View
                    style={{
                      padding: 1,
                      backgroundColor: "#666666",
                      width: "30%",
                      height: 1,
                    }}
                  ></View>
                </View>
              </>


              <Text style={{ fontSize: 16, marginVertical: 6, fontWeight: 'bold' }}>Card Information</Text>
              <PaymenInput
                label="Card Number"
                mask={'9999 9999 9999 9999'}
                fieldName="card_number"
                placeholder={'Card Number'}
              />
              <PaymenInput
                label="Card Expiry"
                fieldName="expiry_date"
                mask={'99/99'}

                placeholder={'MM/YY'}
              />
              <PaymenInput
                label="CVC"
                fieldName="cvc"
                mask={'999'}
                placeholder={'CVC'}
              />
              <Button
                style={{
                  backgroundColor: "#1B588A",
                  borderRadius: 8,
                }}
                onPress={()=>createWash()}
                // loading={loading}

                preset="primary"
                text={`Pay $${selectedPlan?.StationServicePrice}`}
              />
            </ScrollView>
          </StripeProvider>
        )}
      </RedeemContainer>
    </ScrollView>
  );
};

export default PaymentType;