import { Platform, View } from "react-native";
import React, { FC, useEffect, useState } from "react";

import { StackScreenProps } from "@react-navigation/stack";
import { HomeNavigatorParamList } from "../home/home-stack";
import { Layout } from "../../../components/washub/layout";
import LocationsMap from "../../../components/washub/locations/locations-map";
import LocationsNearby from "../../../components/washub/locations/locations-nearby";
import { ToggleMode } from "../../../components/washub/toggle-mode/toggle-mode";
import { styles } from "./locations.styles";
import { Location } from "../../../../../shared/global-types";
import { useAppState } from "../../../context/app-state-context";

const isIOS = Platform.OS === "ios";

const LocationsScreen: FC<
  StackScreenProps<HomeNavigatorParamList, "locations">
> = ({ navigation, route }) => {
  const [washLocations, setWashLocations] = useState<Location[]>([]);
  const [isMapMode, setIsMapMode] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const { appState } = useAppState();

  useEffect(() => {
    return () => {
      setIsLoading(false);
      setWashLocations([]);
      setIsMapMode(true);
    };
  }, []);

  return (
    <Layout hasContainer={!isMapMode}>
      {isMapMode ? (
        <LocationsMap
          handleWashLocations={setWashLocations}
          handleIsLoading={setIsLoading}
          card={appState.selectedCard}
        />
      ) : (
        <LocationsNearby washLocations={washLocations} />
      )}
      {!isLoading && (
        <View
          style={{
            ...styles.buttonWrapper,
          }}
        >
          <ToggleMode
            handleOnPress={() => setIsMapMode(!isMapMode)}
            isMapMode={isMapMode}
          />
        </View>
      )}
    </Layout>
  );
};

export default LocationsScreen;
