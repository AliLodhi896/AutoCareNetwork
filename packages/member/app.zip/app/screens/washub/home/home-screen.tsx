import React, { FC, useEffect, useState,useCallback } from "react";
import { View } from "react-native";
import { StackScreenProps } from "@react-navigation/stack";
import { styles } from "./home-screen.styles";
import { screenDimensions } from "../../../../../shared/theme";
import { useAppState } from "../../../context/app-state-context";
import { Card } from "../../../../../shared/services/api";
import { HomeNavigatorParamList } from "./home-stack";
import { ScrollView, TouchableOpacity } from "react-native-gesture-handler";

import { useAuthState } from "../../../../../shared/contexts/auth-state-context";
import { Text } from "../../../../../shared/components/text/text";
import { normalize } from "../../../../../shared/utils/normalize";
import CarsCarousel from "../../../components/washub/cars-carousel/cars-carousel";
import { Layout } from "../../../components/washub/layout";
import { Loader } from "../../../components/washub/loader/loader";
import { AutoImage } from "../../../../../shared/components";
import TermsAndConditions from "../../../components/washub/terms-and-conditions/terms-and-conditions";
import { ICardStatus } from "../../../washub-types";
import { AuthStateProps } from "../../../../../shared/services/storage";
import analytics from "@react-native-firebase/analytics";
import { useFocusEffect } from "@react-navigation/native";

export const HomeScreen: FC<
  StackScreenProps<HomeNavigatorParamList, "default">
> = ({ navigation, route }) => {
  const { authState, initializeAuth } = useAuthState();
  const { appState } = useAppState();

  const { profile } = authState;
  const cards: Array<Card> = appState.cards;

  const [carouselCards, setCarouselCards] = useState<Card[]>([]);

  useEffect(() => {
    const sliderCards = [];
    cards?.forEach((card) => {
      if (card.CardStatus === ICardStatus.Active) {
        sliderCards.push(card);
      } else {
        appState.recentWashes.forEach((rw) => {
          if (rw.CardCode === card.CardCode) {
            sliderCards.push(card);
          }
        });
      }
    });
    setCarouselCards(sliderCards);
    return () => {
      setCarouselCards([]);
    };
  }, []);
  const activeCards = cards?.filter((c) => c.CardStatus === "Active");
  const updateEvent = async () => {
    const state: AuthStateProps = await initializeAuth();
    await analytics().setUserId(JSON.stringify(state?.profile?.UserId));
  }

  const scrreenView = async () => {
    await analytics().logEvent('screen_view', {
      screen_name: 'Welcome',
    });
  }

  useFocusEffect(
    useCallback(() => {
      updateEvent()
      scrreenView()
    }, []),
  );

  return (
    <Layout headerManufacturer hasContainer={false}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        style={{
          minHeight: screenDimensions.height,
          width: screenDimensions.width,
        }}
      >
        <TermsAndConditions />
        <View
          style={{
            minHeight: screenDimensions.height,
            width: screenDimensions.width,
          }}
        >
          <View style={styles.container}>
            <View style={styles.titleView}>
              <Text style={styles.title}>Welcome, {profile?.FirstName}</Text>
            </View>
            {appState.isLoading ? (
              <View style={{ flex: 1, position: "relative" }}>
                <Loader />
              </View>
            ) : carouselCards.length === 0 ? (
              <View style={{ flex: 1, position: "relative" }}>
                <View style={styles.noCardsView}>
                  <Text style={styles.noCardsText}>You have no Cards</Text>
                </View>
              </View>
            ) : (
              <CarsCarousel cards={carouselCards} />
            )}
          </View>
          {appState.selectedCard && (
            <View style={[styles.bottomView, { marginTop: normalize(20) }]}>
              <TouchableOpacity
                onPress={() => {
                  navigation.navigate("redeem");
                }}
              >
                <AutoImage
                  style={styles.bntCircle}
                  source={require("../../../../assets/images/btn-find-wash.png")}
                />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={async () => {

                  navigation.navigate("products");
                }
                }
              // onPress={() => {

              // }}
              >
                <AutoImage
                  style={styles.bntCircle}
                  source={require("../../../../assets/images/btn-book-service.png")}
                />
              </TouchableOpacity>
            </View>
          )}
        </View>
      </ScrollView>
    </Layout>
  );
};
