import React, { FC, useEffect, useReducer } from "react";
import { StackScreenProps } from "@react-navigation/stack";
import { HomeNavigatorParamList } from "../home/home-stack";
import { Layout } from "../../../components/washub/layout";
import { Loader } from "../../../components/washub/loader/loader";
import {
  RedemptionType,
  IRequestStatus,
  BarCodeType,
  ILastRedemption,
} from "../../../washub-types";
import redemptionReducer, {
  IStatus,
  initialState,
} from "../../../components/washub/redeem/redemptionReducer";
import WashubClient from "../../../services/api/api";
import QRCode from "react-native-qrcode-svg";
import { Text } from "../../../../../shared/components";
import { styles } from "./redeem-location.styles";
import { fontsize } from "../../../../../shared/theme";
import { normalize } from "../../../../../shared/utils/normalize";
import Barcode from "react-native-barcode-builder";
import { TouchableOpacity, View } from "react-native";
import { ErrorDrop } from "../../../components/washub/error-drop/error-drop";
import { useAppState } from "../../../context/app-state-context";

const RedeemLocationScreen: FC<
  StackScreenProps<HomeNavigatorParamList, "redeemLocation">
> = ({ navigation, route }) => {
  const station = route.params.station;
  const card = route.params.card;
  const { appState, setAppState } = useAppState();

  const [{ data, reqStatus, error }, dispatch] = useReducer(
    redemptionReducer,
    initialState
  );
  const { VehicleInfo } = card;

  useEffect(() => {
    redeem();
  }, []);

  const redeem = async () => {
    dispatch({ type: IStatus.Request });
    await WashubClient.redeemWash({
      CardCode: card.CardCode,
      StationId: station.LocationId,
      selfValidated: station.AllowsSelfValidation,
    })
      .then(async (response) => {
        if (response.error === null && response.result) {
          const redemptionType =
            response.result.BarCodeInfo?.BarCodeFormat ??
            RedemptionType.CardCode;

          dispatch({
            type: IStatus.Success,
            result: { ...response.result, RedemptionType: redemptionType },
          });
          const redemption: ILastRedemption = {
            station: station,
            card: card,
          };
          setAppState({
            lastRedemption: redemption,
            mileageSaved: appState.mileageSaved + 1,
          });
        }
        if (response.error !== null) {
          dispatch({ type: IStatus.Error, error: response.error.message });
        }
      })
      .catch((error) => {
        dispatch({ type: IStatus.Error, error: "Unknow error" });
      });
  };

  const renderRedemptionCode = () => {
    if (!data) return null;
    switch (data.RedemptionType) {
      case RedemptionType.QrCode:
        return (
          <>
            <QRCode
              backgroundColor="#ffffff"
              color="#000000"
              value={String(data.RedemptionCode)}
              size={normalize(150)}
            />
            <Text
              style={[styles.textCode, { fontSize: fontsize["medium+"] }]}
              text={data.RedemptionCode}
            />
          </>
        );
      case RedemptionType.BarCode39:
      case RedemptionType.BarCode128:
        return (
          <>
            <Barcode
              value={String(data.RedemptionCode)}
              format={BarCodeType[data.RedemptionType]}
              background="#ffffff"
              lineColor="#000000"
              width={data.RedemptionType === RedemptionType.BarCode39 ? 1 : 2}
            />
            <Text
              style={[styles.textCode, { fontSize: fontsize["medium+"] }]}
              text={data.BarCodeInfo.BarCodeDisplay}
            />
          </>
        );
      case RedemptionType.CardCode:
        return (
          <View style={styles.textContainer}>
            <View>
              <Text style={styles.textCode} text={data.RedemptionCode} />
            </View>
          </View>
        );

      default:
        return null;
    }
  };

  if (reqStatus === IRequestStatus.Pending) {
    return <Loader />;
  }

  if (error) {
    return (
      <ErrorDrop text="Your maximum number of washes per month has already been used." />
    );
  }

  return (
    <Layout>
      <View style={{ flex: 1, flexDirection: "column" }}>
        <View style={{ flex: 21 }}>
          <View style={styles.container}>
            <View style={styles.codeWrapper}>{renderRedemptionCode()}</View>
            <Text style={styles.title} text="LOOKS LIKE YOU’RE HERE!" />
            {data && (
              <Text style={[styles.text, { marginTop: normalize(10) }]}>
                {data.RedmptionInstructions.replace("below", "above").replace(
                  ":",
                  ""
                )}
              </Text>
            )}
            <View style={styles.stationInfo}>
              <Text
                style={styles.stationName}
                text={station.LocationName.toUpperCase()}
              />
              <Text style={styles.stationAddr} text={station.LocationAddress} />
            </View>

            {VehicleInfo && (
              <Text
                style={[styles.text, styles.textCar]}
                text={`${VehicleInfo.Year} ${VehicleInfo.Make} ${VehicleInfo.Model}`}
              />
            )}
            {VehicleInfo && (
              <View style={styles.licensePlate}>
                <Text style={styles.licensePlateText} text="License Plate" />
                <Text
                  style={styles.licensePlateNumber}
                  text={
                    VehicleInfo.LicensePlateState +
                    VehicleInfo.LicensePlateNumber
                  }
                />
              </View>
            )}
            <View style={styles.linksWrapper}>
              <TouchableOpacity
                style={styles.links}
                onPress={() => {
                  navigation.navigate("default", { screen: "home" });
                }}
              >
                <Text
                  style={[styles.actionLink, styles.actionLinkXS]}
                  text="<"
                />
                <Text style={styles.actionLink} text="I'm all done" />
              </TouchableOpacity>
            </View>
          </View>
        </View>
        <View style={{ flex: 2 }} />
      </View>
    </Layout>
  );
};

export default RedeemLocationScreen;
