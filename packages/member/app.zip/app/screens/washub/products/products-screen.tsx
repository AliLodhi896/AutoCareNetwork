import React, { useCallback, FC, useEffect, useState } from "react";
import { View } from "react-native";
import { StackScreenProps } from "@react-navigation/stack";
import { Text } from "../../../../../shared/components";

import { styles } from "./products-screen.style";

import { Product } from "../../../../../shared/services/api";
import { HomeNavigatorParamList } from "../home/home-stack";
import { FlatList } from "react-native-gesture-handler";
import {
  ActionType,
  ProductItem,
} from "../../../components/washub/product-item/product-item";
import { Layout } from "../../../components/washub/layout";
import { useAppState } from "../../../context/app-state-context";
import { useFocusEffect } from "@react-navigation/native";
import analytics from '@react-native-firebase/analytics';

export const ProductsScreen: FC<
  StackScreenProps<HomeNavigatorParamList, "products">
> = ({ navigation, route }) => {
  const { appState } = useAppState();

  const card = appState.selectedCard;
  const [products, setProducts] = useState<Product[]>([]);

  useEffect(() => {
    const bookServices = card.Products.filter(
      (p) => p.Actions.indexOf(ActionType.BookService) === 0
    );
    const fileClaims = card.Products.filter(
      (p) => p.Actions.indexOf(ActionType.FileClaim) === 0
    );

    setProducts([...bookServices, ...fileClaims]);

    return () => {
      setProducts([]);
    };
  }, [card]);

  const productAnalytics = async () => {
    try {
      if(card?.Products?.length !== 0){
        const items = card?.Products?.map(item => ({
          item_brand:card?.DealerName + ' ' + card?.DealerId,
          item_name:item?.ProductName ,
          item_id:item?.DealerProductId ,
          location_id:card?.DealerAddress ,
          affiliation:card?.DealerName + ' ' +  card?.DealerId,
        }));
        await analytics().logEvent('view_item_list', {
          item_list_id: 'products_servicecs',
          item_list_name: 'Products and Services',
          items: items
        })
      }

    } catch (error) {
      console.error('Error logging event:', error);
    }
  }


  const scrreenView =  async () => {
    await analytics().logEvent('screen_view', {
      screen_name: 'Product And Services',
    });
  }

  useFocusEffect(
    useCallback(() => {
      productAnalytics()
      scrreenView()
    }, []),
  );

  return (
    <Layout>
      <FlatList
        contentContainerStyle={styles.listContainer}
        data={products}
        renderItem={({ item }: { item: Product }) => (
          <ProductItem product={item} card={card} />
        )}
        keyExtractor={({ item }: { item: Product }, key) => key.toString()}
        ListHeaderComponent={
          <Text style={styles.title}>Products & Services</Text>
        }
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListEmptyComponent={() => (
          <Text style={styles.emtpyList} text="No Products or Services found" />
        )}
      />
    </Layout>
  );
};
