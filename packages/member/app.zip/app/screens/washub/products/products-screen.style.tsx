import { spacings, fontsize, typography } from "../../../../../shared/theme";
import { StyleSheet } from "react-native";
import { normalize } from "../../../../../shared/utils/normalize";

export const styles = StyleSheet.create({
  listContainer: {
    flexDirection: "column",
    alignItems: "center",
    paddingBottom: normalize(170),
  },
  title: {
    color: "#1B588A",
    fontSize: normalize(30),
    fontFamily: typography.primary,
    fontWeight: "bold",
    marginTop: spacings["medium+"],
    marginBottom: spacings["mediumOne+"],
  },
  separator: {
    height: normalize(45),
  },
  emtpyList: {
    marginTop: normalize(40),
    marginHorizontal: normalize(42),
    textAlign: "center",
    fontSize: fontsize.medium,
    fontFamily: typography.primary,
  },
});
