import React, { FC, useEffect, useState } from "react";
import { StackScreenProps } from "@react-navigation/stack";
import { HomeNavigatorParamList } from "../home/home-stack";
import { Layout } from "../../../components/washub/layout";
import RedeemContainer from "../../../components/washub/redeem-container";
import { View } from "react-native";
import { styles } from "../location-detail/location-detail.styles";
import { CircleActionButton } from "../../../components/washub/circle-action-button/circle-action-button";
import HasFreeWash from "../has-free-wash/has-free-wash";
import { WashPlan } from "../../../components/washub/redeem/wash-plan";

const WashType: FC<
  StackScreenProps<HomeNavigatorParamList, "locationDetail">
> = ({ navigation, route }) => {
  const [showFreeInfo, setShowFreeInfo] = useState<boolean>(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null)

  const station = route.params.station;
  useEffect(() => {
    return () => {
      setShowFreeInfo(false);
    };
  }, []);

  const isPremiumOnly = false;
  const containerStyle = isPremiumOnly
    ? styles.premiumContainer
    : styles.container;
  return (
    <Layout>
      <RedeemContainer showBack={!showFreeInfo}>
        {showFreeInfo ? (
          <HasFreeWash handleClose={() => setShowFreeInfo(false)} />
        ) : (
          <View style={containerStyle}>
            <WashPlan setSelectedPlan={(values) => setSelectedPlan(values)} isPremiumOnly={isPremiumOnly} station={station} />
            <CircleActionButton
              disabled={selectedPlan == null || selectedPlan == undefined ? true : false}
              style={[{ ...styles.redeemButton }, { opacity: selectedPlan == null || selectedPlan == undefined ? 0.7 : 1 }]}
              textStyle={{ ...styles.payNowButtonText }}
              text={"PAY NOW"}
              onPress={() => navigation.navigate('paymentType', { selectedPlan: selectedPlan,station:station })}
            />
          </View>
        )}
      </RedeemContainer>
    </Layout>
  );
};

export default WashType;
