import React, { FC, useEffect, useState } from "react";
import { StackScreenProps } from "@react-navigation/stack";
// import intercomService from "../../../../shared/services/intercom.service";
// import Intercom, { IntercomEvents } from "@intercom/intercom-react-native";
import { TabNavigatorParamList } from "../../navigators/tab-bar";
import { useAuthState } from "../../../../shared/contexts/auth-state-context";
import { useIsFocused } from "@react-navigation/native";

export const ChatScreen: FC<
  StackScreenProps<TabNavigatorParamList, "chat">
> = ({ navigation }) => {
  // const { authState } = useAuthState();
  // const [countEvents, setCountEvents] = useState(null);
  // const isFocused = useIsFocused();

  // useEffect(() => {
  //   if (isFocused) {
  //     Intercom.displayMessenger();
  //   }
  // }, [isFocused]);

  // useEffect(() => {
  //   if (authState.profile) {
  //     intercomService.loadIntercom(authState.profile.Email);
  //   }
  // }, [authState.profile?.Email]);

  // useEffect(() => {
  //   // const countListener = Intercom.addEventListener(
  //   //   IntercomEvents.IntercomUnreadCountDidChange,
  //   //   (response) => {
  //   //     setCountEvents(response.count as number);
  //   //   }
  //   // );
  //   const hideListener = Intercom.addEventListener(
  //     IntercomEvents.IntercomWindowDidHide,
  //     (response) => {
  //       console.log(response);

  //       navigation.navigate("home");
  //     }
  //   );

  //   return () => {
  //     hideListener.remove();
  //   };
  // }, []);

  return <></>;
};
