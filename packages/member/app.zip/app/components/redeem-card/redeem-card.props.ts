export interface RedeemProps {
  id: number;
  name: string;
  address: string;
  street: string;
  phone: string;
  type: string;
  mile: number;
}