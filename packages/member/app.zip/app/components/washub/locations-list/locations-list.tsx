import React, { useCallback, useEffect } from "react";
import { Text } from "../../../../../shared/components/text/text";
import { View } from "react-native";
import { styles } from "./locations-list.style";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import { CircleActionButton } from "../circle-action-button/circle-action-button";
import { FlatList } from "react-native-gesture-handler";
import { Location } from "../../../../../shared/global-types";
import useDistanceMiles from "../../../hooks/useDistanceMiles";
import { PinColors } from "../../../washub-types";
import analytics from '@react-native-firebase/analytics';


const LocationItem: React.FC<{ item: Location }> = ({ item }) => {

  const navigation = useNavigation();
  const { distanceMiles } = useDistanceMiles(item);

  return (
    <View style={styles.item}>
      <View style={styles.itemData}>
        <Text style={{ ...styles.itemText, ...{ fontWeight: "bold" } }}>
          {item.LocationName}
        </Text>
        {Array.isArray(item.StationServices) &&
          item.StationServices.length > 0 && (
            <Text
              style={{
                ...styles.itemText,
                ...{ fontWeight: "bold", color: PinColors.red },
              }}
              text="PREMIUM SERVICE ONLY"
            />
          )}

        <Text style={styles.itemText}>{item.LocationAddress}</Text>
        <Text style={styles.itemText}>
          {item.LocationCity}, {item.LocationState}
        </Text>
        <Text style={styles.itemText}>{item.LocationPhone}</Text>
      </View>
      <View>
        {distanceMiles !== null && (
          <Text style={styles.actionButtonText}>
            {distanceMiles !== 0 ? distanceMiles.toFixed(2) : distanceMiles}{" "}
            miles
          </Text>
        )}
        <CircleActionButton
          style={styles.actionButton}
          text="SELECT"
          onPress={() => {
            navigation.navigate("locationDetail", { station: item });
          }}
        />
      </View>
    </View>
  );
};

export function LocationsList({
  washLocations,
  title,
  emptyListText,
  customStyle,
  recentWash
}: {
  washLocations: any
  recentWash: any;
  title: string;
  emptyListText: string;
  customStyle: {
    container: any;
  };
}) {

  const washPlansAnalytics = async () => {
    try {
      const items = recentWash.map(item => ({
        item_brand: item?.ServiceLevel,
        item_name: item?.LocationName,
        item_id: item?.LocationId,
        location_id: item?.LocationGooglePlacesId,
        item_category: 'car wash',
        affiliation: '*Pitch Deck - 222560201',
        item_category2: 'Premium Only',
      }));

      await analytics().logEvent('view_item_list', {
        item_list_id: 'recent_washes',
        item_list_name: 'Recent Washes',
        items: items
      })
    } catch (error) {
      console.error('Error logging event:', error);
    }
  }

  useEffect(() => {
    washPlansAnalytics()
  }, [recentWash])


  return (
    <View style={{ ...styles.container, ...customStyle.container }}>
      <Text style={styles.title}>{title}</Text>
      <FlatList
        contentContainerStyle={styles.listContainer}
        data={washLocations}
        renderItem={({ item }: { item: Location }) => (
          <LocationItem item={item} />
        )}
        keyExtractor={(item, key) => {
          return item.LocationId + key.toString();
        }}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
        ListFooterComponent={() => <View style={styles.footer} />}
        ListEmptyComponent={() => (
          <Text style={styles.emtpyList} text={emptyListText} />
        )}
      />
    </View>
  );
}

LocationsList.defaultProps = {
  emptyListText: "No locations found",
  customStyle: {
    container: {},
  },
};
