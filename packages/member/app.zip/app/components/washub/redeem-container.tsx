import { View } from "react-native";
import React, { useState } from "react";
import { useNavigation } from "@react-navigation/native";
import { TextButton } from "./text-button/text-button";

interface ContainerPorps {
  showBack?: boolean;
  children: React.ReactNode;
}

const RedeemContainer = ({ showBack, children }: ContainerPorps) => {
  const navigation = useNavigation();

  return (
    <View style={{ flex: 1, flexDirection: "column" }}>
      <View style={{ flex: showBack ? 4 : 2 }}>
        {showBack && navigation.canGoBack() && (
          <TextButton handleOnPress={() => navigation.goBack()} />
        )}
      </View>

      <View style={{ flex: 21 }}>{children}</View>
      <View style={{ flex: 2 }} />
    </View>
  );
};

export default RedeemContainer;
RedeemContainer.defaultProps = {
  showBack: true,
};
