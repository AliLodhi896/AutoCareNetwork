import React, { useEffect, useRef, useState } from "react";
import { Pressable, View, ScrollView, useWindowDimensions } from "react-native";
import { Text } from "../../../../../shared/components";
import { styles } from "./terms-and-conditions.style";
import WashubClient from "../../../services/api/api";
import RenderHtml from "react-native-render-html";
import { useAppState } from "../../../context/app-state-context";
import Modal from "react-native-modal";
import { useAuthState } from "../../../../../shared/contexts/auth-state-context";
import { decode } from "html-entities";
import { Loader } from "../loader/loader";

const TermsAndConditions = () => {
  const { appState } = useAppState();
  const scrollRef = useRef<ScrollView>(null);
  const [termsAndConditions, setTermsAndConditions] = useState("");
  const [modalVisible, setModalVisible] = useState(false);
  const screenDimensions = useWindowDimensions();
  const { authState, setAuthState } = useAuthState();

  useEffect(() => {
    (async () => {
      try {
        const { response } = await WashubClient.getTerms();
        setTermsAndConditions(response.data.Terms);
      } catch (err) {
        console.warn(err);
      }
    })();
  }, []);

  useEffect(() => {
    if (!authState.AcceptTerms && !appState.isLoading && termsAndConditions) {
      setTimeout(() => setModalVisible(true), 500);
    } else {
      setModalVisible(false);
    }
  }, [authState.AcceptTerms, appState.isLoading, termsAndConditions]);

  const acceptTerms = async () => {
    await WashubClient.acceptTerms();
    setModalVisible(false);
    setAuthState({ AcceptTerms: true });
  };

  return (
    <Modal
      animationIn="fadeInLeft"
      animationOut={"fadeOutRight"}
      animationInTiming={500}
      animationOutTiming={500}
      propagateSwipe
      accessibilityViewIsModal
      backdropTransitionOutTiming={0}
      backdropOpacity={0.85}
      isVisible={modalVisible}
      style={{
        alignItems: "center",
        justifyContent: "center",
        margin: 40,
      }}
      statusBarTranslucent={true}
      deviceHeight={screenDimensions.height}
      deviceWidth={screenDimensions.width}
      useNativeDriver={false}
      avoidKeyboard
    >
      {termsAndConditions !== "" && (
        <>
          <ScrollView
            scrollEnabled={true}
            showsVerticalScrollIndicator={true}
            style={styles.modalContentContainer}
            ref={scrollRef}
          >
            <View style={styles.modalContainer}>
              <RenderHtml
                contentWidth={200}
                source={{ html: decode(termsAndConditions) }}
              />
            </View>
          </ScrollView>

          <Pressable
            style={[styles.modalButton]}
            onPress={async () => await acceptTerms()}
          >
            <Text style={styles.buttonText}>Accept T&C</Text>
          </Pressable>
        </>
      )}
    </Modal>
  );
};

export default TermsAndConditions;
