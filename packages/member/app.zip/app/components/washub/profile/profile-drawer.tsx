import React, { useEffect, useState } from "react";
import { FlatList, Pressable, View, LayoutAnimation } from "react-native";
import { Text } from "../../../../../shared/components/text/text";
import { styles } from "./profile-drawer.style";
import { useAuthState } from "../../../../../shared/contexts/auth-state-context";
import ArrowDown from "../../svg/arrow-down";
import ArrowUp from "../../svg/arrow-up";
import { ProfileHead } from "./profile-head";
import { useAppState } from "../../../context/app-state-context";
import AccountVehicles from "./account/account-vehicles";
import AccountPlans from "./account/account-plans";
import { ICardStatus } from "../../../washub-types";
import AccountProfile from "./account/account-profile";
import AccountPlanHisotry from "./account/account-plan-history";
import { Card } from "../../../services/api";
import analytics from "@react-native-firebase/analytics";

interface IMenuItem {
  id: number;
  title: string;
  component: JSX.Element | null;
}
export enum MENU_ID {
  MY_PLANS = 1,
  MY_VEHICLES = 2,
  MEMBERSHIP_HISTORY = 3,
  MY_PROFILE = 4,
  MY_MEMBER_NUMBERS = 5,
}
const CUSTOM_MENU = [MENU_ID.MY_PLANS];

export const ProfileDrawer = ({ navigation }) => {
  const { authState } = useAuthState();
  const { appState } = useAppState();
  const [openNewMembership, setOpenNewMembership] = useState<boolean>(false);
  const [addVinNumberCard, setAddVinNumberCard] = useState<Card | null>(null);

  const expiredCards = appState.cards?.filter(
    (c) => c.CardStatus !== ICardStatus.Active
  );

  const availableCards = appState.cards?.filter(
    (c) => c.CardStatus === ICardStatus.Active
  );

  const [activeMenu, setActiveMenu] = useState<number | null>(null);
console.log(activeMenu)
  useEffect(() => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    return () => {
      setActiveMenu(null);
      setOpenNewMembership(false);
      setAddVinNumberCard(null);
    };
  }, []);

  const toggleAddNew =  (show) => {
    setActiveMenu(MENU_ID.MY_PLANS);
    setOpenNewMembership(show);
  };

  const toggleAddVin = (card) => {
    setActiveMenu(MENU_ID.MY_PLANS);
    setAddVinNumberCard(card);
  };

  const closeDrawer = async (refetch?: boolean) => {
    await analytics().logEvent('screen_view', {
      screen_name: 'My Plans',
    });
    navigation.closeDrawer();
    setActiveMenu(null);
  };

  const menuItems: IMenuItem[] = [
    {
      id: MENU_ID.MY_PLANS,
      title: "My Plans",
      component: (
        <AccountPlans
          cards={availableCards}
          openNew={openNewMembership}
          addVinNumberCard={addVinNumberCard}
          handleClose={() => closeDrawer(true)}
        />
      ),
    },
    {
      id: MENU_ID.MY_VEHICLES,
      title: "My vehicles",
      component: (
        <AccountVehicles
          cards={availableCards}
          handleAddNew={toggleAddNew}
          handleAddVin={toggleAddVin}
        />
      ),
    },
    {
      id: MENU_ID.MEMBERSHIP_HISTORY,
      title: "My Plan History",
      component: <AccountPlanHisotry cards={expiredCards} />,
    },
    {
      id: MENU_ID.MY_PROFILE,
      title: "My Profile",
      component: <AccountProfile user={authState.profile} />,
    },
  ];

  const renderMenuItem = ({ item }) => {
    return (
      <>
        <Pressable
          style={styles.menuCard}
          onPress={ async () => {
            await analytics().logEvent('screen_view', {
              screen_name: item?.id == 1 ? 'My Profile - My Plans' : item?.id == 2 ? 'My Profile - My Vehicles' : item?.id == 3 ? 'My Profile - Membership History' : 'My Profile' ,
            });
            LayoutAnimation.configureNext(
              LayoutAnimation.Presets.easeInEaseOut
            );
            setActiveMenu(item.id === activeMenu ? null : item.id);
          }}
        >
          <Text style={styles.menuCardText}>{item.title.toUpperCase()}</Text>
          {item.id === activeMenu ? <ArrowDown /> : <ArrowUp />}
        </Pressable>
        {item.id === activeMenu && item.component}
      </>
    );
  };

  if (authState.profile === null) return <></>;

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 2, justifyContent: "flex-end" }}>
        <ProfileHead
          user={authState.profile}
          handleClose={() => closeDrawer()}
        />
      </View>
      <View style={[styles.container, { flex: 12 }]}>
        {CUSTOM_MENU.includes(activeMenu) ? (
          <View style={styles.customMenu}>
            <View style={styles.customTop}>
              <Pressable
                onPress={() => {
                  toggleAddNew(false);
                  toggleAddVin(false);
                  setActiveMenu(null);
                }}
                style={styles.backContainer}
              >
                <Text
                  style={{ ...styles.backButton, ...styles.backButtonXS }}
                  text="<"
                />
                <Text style={styles.backButton} text="BACK" />
              </Pressable>
            </View>
            <View style={styles.customBody}>
              {menuItems.find((m) => m.id === activeMenu).component}
            </View>
          </View>
        ) : (
          <FlatList
            style={styles.flatList}
            data={menuItems}
            keyExtractor={(item) => item.id.toString()}
            renderItem={renderMenuItem}
          />
        )}
      </View>
    </View>
  );
};
