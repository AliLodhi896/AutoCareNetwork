import React, { useEffect } from "react";
import { View } from "react-native";
import { styles } from "./toggle-mode.style";
import { CircleActionButton } from "../circle-action-button/circle-action-button";

interface ToggleModeProps {
  handleOnPress: () => void;
  isMapMode: boolean;
}

export function ToggleMode({ isMapMode, handleOnPress }: ToggleModeProps) {
  return (
    <View>
      <CircleActionButton
        style={styles.actionButton}
        text={isMapMode ? "LIST VIEW" : "MAP VIEW"}
        onPress={() => {
          handleOnPress();
        }}
      />
    </View>
  );
}
