import {
  View,
  Platform,
  Alert,
  PermissionsAndroid,
  ActivityIndicator,
} from "react-native";

import React, { useCallback, useEffect, useRef, useState } from "react";
import { styles } from "./locations-map.styles";
import MapView, { Marker, PROVIDER_GOOGLE } from "react-native-maps";
import { customMapStyles } from "./customMapStyles";
import Geocoder from "react-native-geocoding";
import Geolocation, {
  GeolocationResponse,
} from "@react-native-community/geolocation";
import { Location } from "../../../../../shared/global-types";
import Pin from "../pin/pin";
import WashubClient from "../../../services/api/api";
import { useFocusEffect, useNavigation } from "@react-navigation/native";
import SearchBar from "../search-bar/search-bar";
import { Card } from "../../../services/api";
import { useRedeemFlow } from "../../../context/redeem-context";
import { Text } from "../../../../../shared/components";
import { normalize } from "../../../../../shared/utils/normalize";
import MapPinXsIcon from "../../svg/map-pin-xs";
import { PinColors } from "../../../washub-types";
import analytics from '@react-native-firebase/analytics';
const isIOS = Platform.OS === "ios";

Geocoder.init("AIzaSyDRIXm45vxIpoMUO-fgjZBFOyBcCxojCxI"); // use a valid API key

const INITIAL_REGION = {
  // 40.69868,-73.70545
  latitude: 40.69868,
  longitude: -73.70545,
  latitudeDelta: 20.0922,
  longitudeDelta: 20.0421,
};

const GetMarker = (props: {
  loc: Location;
  locationSelected: (loc: Location) => void;
}) => {
  const { loc, locationSelected } = props;
  const coord = {
    latitude: parseFloat(loc.LocationLatitude),
    longitude: parseFloat(loc.LocationLongitude),
  };

  return (
    <Marker
      key={loc.LocationId + Math.random()}
      identifier={loc.LocationName}
      coordinate={coord}
      onPress={() => locationSelected(loc)}
      tracksViewChanges={false}
    >
      <Pin station={loc} />
    </Marker>
  );
};

interface ILocationsMap {
  handleWashLocations: (locations: Location[]) => void;
  handleIsLoading: (x: boolean) => void;
  card: Card | null;
}
const LocationsMap = ({
  handleWashLocations,
  handleIsLoading,
  card,
}: ILocationsMap) => {
  const { setRedeemState } = useRedeemFlow();
  const mapRef = useRef<MapView>(null);
  const watchIDRef = useRef<number>();
  const navigation = useNavigation();
  const [currentRegion, setCurrentRegion] = useState(INITIAL_REGION);
  const [washLocations, setWashLocations] = useState([]);
  const [userLocation, setUserLocation] = useState<GeolocationResponse>();
  const [loading, setLoading] = useState(true);
  const [searchLocation, setSearchLocation] = useState<{
    latitude: number;
    longitude: number;
  }>();
  const [autoFit, setAutoFit] = useState<boolean>(true);

  useEffect(() => {
    handleIsLoading(loading);
  }, [loading]);

  useEffect(() => {
    if (autoFit && washLocations?.length > 0) {
      fitToMarkers(washLocations);
    }
  }, [autoFit, washLocations]);

  useEffect(() => {
    handleWashLocations(washLocations);
  }, [washLocations]);

  useEffect(() => {
    return () => {
      Geolocation.clearWatch(watchIDRef.current);
    };
  }, [searchLocation]);

  useEffect(() => {
    return () => {
      setAutoFit(true);
      setCurrentRegion(INITIAL_REGION);
      setWashLocations([]);
      setUserLocation(undefined);
      setLoading(true);
      setSearchLocation(undefined);
    };
  }, []);

  const search = useCallback(async (latitude: number, longitude: number) => {
    const success = (locations: any) => {
      setWashLocations(locations || []);
      setAutoFit(autoFit ? false : true);
      Platform.OS === "android"
        ? setTimeout(() => {
          setLoading(false);
        }, 5000)
        : setLoading(false);
      setSearchLocation({
        latitude,
        longitude,
      });
    };
    const failure = (message: string, code: number) => {
      setWashLocations([]);
      setLoading(false);
      showError(message);
    };
    setLoading(true);

    await WashubClient.getLocations({
      Latitude: latitude,
      Longitude: longitude,
      Limit: 15,
      CardCode: card?.CardCode.toString() ?? "",
    }).then((result) => {
      if (result.error) {
        const { message, code } = result.error;
        failure(message, code);
      } else {
        success(result.Locations);
      }
    });



  }, []);

  useEffect(() => {
    requestPermission((success) => {
      if (success) {
        Geolocation.getCurrentPosition(
          (position) => {
            setRedeemState({ locationDisabled: false });
            search(position.coords.latitude, position.coords.longitude);
          },
          (error) => {
            console.warn("Error getting position user:", error.message);
            setRedeemState({ locationDisabled: true });
            setLoading(false);
            Alert.alert(
              "Location Services Are Disabled",
              "Please turn location services ON for Autocare Network (in your settings) or search manually by entering a City & State or ZIP Code to find a participating location.",
              [
                {
                  text: "OK",
                  onPress: () => console.log("OK Pressed"),
                },
              ]
            );
          },
          { enableHighAccuracy: true, timeout: 60000, maximumAge: 1000 }
        );
        watchIDRef.current = Geolocation.watchPosition(
          (position) => {
            setUserLocation(position);
          },
          (error) => {
            // Alert.alert("WatchPosition Error", JSON.stringify(error))
            console.log(JSON.stringify(error));
          }
        );
      } else {
        console.warn("User denied location access");
        setLoading(false);
        setRedeemState({ locationDisabled: true });
      }
    });
  }, [search]);

  const fitToMarkers = (locations: any[]) => {
    if (locations?.length === 0) {
      return;
    }
    const names = locations?.map((loc) => loc.LocationName);

    // Add delay for android
    Platform.OS === "android"
      ? setTimeout(() => {
        mapRef.current?.fitToSuppliedMarkers(names, { animated: true });
      }, 200)
      : mapRef.current?.fitToSuppliedMarkers(names, {
        animated: true,
        edgePadding: { top: 30, right: 30, bottom: 30, left: 30 },
      });
  };

  const geocodeText = useCallback(
    (text: string) => {
      // Address Geocoding
      Geocoder.from(text)
        .then((json: any) => {
          // res is an Array of geocoding object (see below)
          const res = json.results;
          if (res && res.length > 0) {
            const match = res[0];
            const newLocation = match.geometry.location;
            const lat = newLocation.lat;
            const long = newLocation.lng;
            search(lat, long);
            setAutoFit(true);
          } else {
            showError("Unable to Find Location, Please Try again.");
          }
        })
        .catch((err: any) => {
          if (err.code === 4) {
            showError(
              "The ZIP code entered is invalid.\nPlease enter a valid ZIP code."
            );
          } else {
            showError(err.message);
          }
        });
    },
    [search]
  );

  const requestPermission = async (completion: (success: boolean) => any) => {
    if (Platform.OS === "ios") {
      Geolocation.requestAuthorization();
      setTimeout(() => {
        completion(true);
      }, 1000);
    } else {
      try {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION
        );
        if (granted === PermissionsAndroid.RESULTS.GRANTED) {
          completion(true);
        } else {
          completion(false);
        }
      } catch (err) {
        completion(false);
        console.warn(err);
      }
    }
  };

  const showError = (error: string) => {
    console.warn(error);
    setLoading(false);
    Alert.alert("Error", error, [
      {
        text: "OK",
        onPress: () => console.log("OK Pressed"),
      },
    ]);
  };
  const locationSelected = (loc: Location) => {
    navigation.navigate("locationDetail", { station: loc });
  };



const searchWashPlansAnalytics = async () => {
  try {
    if(washLocations?.length !== 0){
      const items = washLocations.map(item => ({
        item_brand: item?.ServiceLevel,
        item_name: item?.LocationName,
        item_id: item?.LocationId,
        location_id: item?.LocationGooglePlacesId,
        item_category: 'car wash',
        affiliation: '*Pitch Deck - 222560201',
        item_category2: 'Premium Only',
      }));
      await analytics().logEvent('view_item_list', {
        item_list_id: 'map_list',
        item_list_name: 'Map List',
        items: items
      })
    }
  } catch (error) {
    console.error('Error logging event:', error);
  }
}

useEffect(() => {
  searchWashPlansAnalytics()
}, [washLocations])


const scrreenView =  async () => {
  await analytics().logEvent('screen_view', {
    screen_name: 'Search By Location - Map',
  });
}

useFocusEffect(
  useCallback(() => {
    scrreenView()
  }, []),
);

  return (
    <View style={styles.container}>
      {loading && (
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={"#00BCFF"} />
        </View>
      )}
      <SearchBar
        onSearch={(text: string) => geocodeText(text)}
        loading={loading}
      />
      <MapView
        ref={mapRef}
        initialRegion={currentRegion}
        // region={currentRegion}
        style={{
          flex: 1,
          marginBottom: normalize(60),
        }}
        provider={PROVIDER_GOOGLE}
        customMapStyle={customMapStyles}
        onRegionChange={(region) => {
          setCurrentRegion(region);
        }}
        onRegionChangeComplete={(region, data) => {
          if (data.isGesture) {
            // setCurrentRegion(region);
            search(region.latitude, region.longitude);
          }
        }}
        paddingAdjustmentBehavior="always"
        showsUserLocation={true}
        scrollDuringRotateOrZoomEnabled={false}
        loadingIndicatorColor="#00BCFF"
      >
        {washLocations?.map((loc, index) => (
          <GetMarker
            key={`${index}-${loc.LocationId}`}
            loc={loc}
            locationSelected={locationSelected}
          />
        ))}
      </MapView>
      <View style={styles.legendContainer}>
        <View style={styles.legendItem}>
          <MapPinXsIcon color={PinColors.red} />
          <Text style={styles.legendText} text="Premium Service Only" />
        </View>
        <View style={styles.legendItem}>
          <MapPinXsIcon color={PinColors.blue} />
          <Text style={styles.legendText} text="Included in Plans" />
        </View>
      </View>
    </View>
  );
};

export default LocationsMap;
