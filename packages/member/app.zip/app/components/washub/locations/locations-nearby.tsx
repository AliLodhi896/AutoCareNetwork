import React, { useCallback, useEffect } from "react";
import { Location } from "../../../../../shared/global-types";
import { LocationsList } from "../locations-list/locations-list";
import RedeemContainer from "../redeem-container";
import analytics from '@react-native-firebase/analytics';
import { useFocusEffect } from "@react-navigation/native";

const LocationsNearby = ({ washLocations }: { washLocations: Location[] }) => {

  const searchWashPlansAnalytics = async () => {
    try {
      if(washLocations?.length !== 0){
        const items = washLocations.map(item => ({
          item_brand: item?.ServiceLevel,
          item_name: item?.LocationName,
          item_id: item?.LocationId,
          location_id: item?.LocationGooglePlacesId,
          item_category: 'car wash',
          affiliation: '*Pitch Deck - 222560201',
          item_category2: 'Premium Only',
        }));
        await analytics().logEvent('view_item_list', {
          item_list_id: 'location_list',
          item_list_name: 'Location List',
          items: items
        })
      }
    } catch (error) {
      console.error('Error logging event:', error);
    }
  }
  
  useEffect(() => {
    searchWashPlansAnalytics()
  }, [washLocations])
  
  const scrreenView =  async () => {
    await analytics().logEvent('screen_view', {
      screen_name: 'Search By Location - Nearby',
    });
  }
  
  useFocusEffect(
    useCallback(() => {
      scrreenView()
    }, []),
  );

  return (
    <RedeemContainer>
      <LocationsList recentWash={washLocations} washLocations={washLocations} title="NEARBY CARWASHES" />
    </RedeemContainer>
  );
};

export default LocationsNearby;
