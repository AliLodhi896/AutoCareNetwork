import React from "react";
import {
  TouchableOpacity,
  TouchableOpacityProps,
  StyleProp,
  ViewStyle,
  TextStyle,
} from "react-native";
import { styles } from "./circle-action-button.styles";
import { Text } from "../../../../../shared/components";

interface CircleActionButtonProps extends TouchableOpacityProps {
  text: string;
  onPress: () => void;
  style?: StyleProp<ViewStyle>;
  textStyle?: StyleProp<TextStyle>;
  disabled?: boolean;
}

export const CircleActionButton = (props: CircleActionButtonProps) => {
  const { text, onPress, style, textStyle, disabled } = props;
  return (
    <TouchableOpacity
      onPress={onPress}
      style={[{ ...styles.container }, style]}
      disabled={disabled === true ? true : false}
    >
      <Text style={[{ ...styles.text }, textStyle]}>{text}</Text>
    </TouchableOpacity>
  );
};
