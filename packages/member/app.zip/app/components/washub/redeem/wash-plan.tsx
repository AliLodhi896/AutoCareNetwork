import React, { useState, useCallback, useEffect } from "react";
import { Text } from "../../../../../shared/components/text/text";
import { ActivityIndicator, ScrollView, TouchableOpacity, View } from "react-native";
import { styles } from "./redeem-mileage.style";
import WashubClient from "../../../services/api/api";
import { useAppState } from "../../../context/app-state-context";
import { stat } from "fs";
import analytics from '@react-native-firebase/analytics';
import { useFocusEffect } from "@react-navigation/native";

export function WashPlan({ isPremiumOnly, station, setSelectedPlan }: { isPremiumOnly: boolean, station: any, setSelectedPlan: any }) {
  const [selectedType, setSelectedType] = useState('DELUXE WASH')
  const [loading, setLoading] = useState(true);
  const [washLocations, setWashLocations] = useState([]);
  const [matchedLocation, setMatchedLocation] = useState(null);

  const { appState } = useAppState();

  const search = useCallback(async () => {
    const success = (locations: any) => {
      setWashLocations(locations || []);
      setLoading(false);

    };
    const failure = (message: string, code: number) => {
      setWashLocations([]);
      setLoading(false);
    };
    setLoading(true);
    await WashubClient.getLocations({
      Latitude: station?.LocationLatitude,
      Longitude: station?.LocationLongitude,
      Limit: 15,
      CardCode: appState.selectedCard?.CardCode.toString() ?? "",
    }).then((result) => {
      if (result.error) {
        const { message, code } = result.error;
        failure(message, code);
      } else {
        success(result.Locations);
      }
    });
  }, []);

  useEffect(() => {
    search()
  }, [])

  useEffect(() => {
    const matchedLocation = washLocations?.find(location => location?.LocationId === station?.LocationId);
    if (matchedLocation) {
      setMatchedLocation(matchedLocation);
    }
  }, [washLocations]);

  const PlanAnalytics = async () => {
    try {
    if(matchedLocation?.StationServices?.length !== 0 ||matchedLocation?.StationServices !==null ){
      const items = matchedLocation?.StationServices?.map(item => ({
        item_category: 'car wash',
        affiliation: '*Pitch Deck - 222560201',
        item_category2: 'Premium Only',
        price: item?.StationServicePrice,
        item_variant: item?.StationServiceName
      }));
      await analytics().logEvent('view_item_list', {
        item_list_id: 'car_wash_details_menu_list',
        item_list_name: 'Car Wash Details Menu List',
        item_brand: station?.ServiceLevel,
        item_name: station?.LocationName,
        item_id: station?.LocationId,
        location_id: station?.LocationGooglePlacesId,
        items: items
      })
    }
  
    } catch (error) {
      console.error('Error logging event:', error);
    }
  }
  useEffect(() => {
    PlanAnalytics()
  }, [matchedLocation]);

  const selectedPlanAnalytics = async (item) => {
    console.log('asd')
    try {
      await analytics().logEvent('add_to_cart', {
        item_list_id: 'car_wash_plan',
        item_list_name: 'Car Wash plan',
        item_brand: station?.LocationName,
        item_id: item?.StationServiceId,
        item_category: 'car wash',
        location_id: station?.LocationGooglePlacesId,
        affiliation: '*Pitch Deck - 222560201',
        price: item?.StationServicePrice,
        item_variant: item?.StationServiceName
      });
      setSelectedPlan(item)
    } catch (error) {
      console.error('Error logging event:', error);
    }
  }


  const scrreenView = async () => {
    await analytics().logEvent('screen_view', {
      screen_name: 'Select Wash',
    });
  }

  useFocusEffect(
    useCallback(() => {
      scrreenView()
    }, []),
  );


  return (
    <ScrollView>
      {loading ?
        <View style={styles.loader}>
          <ActivityIndicator size="large" color={"#00BCFF"} />
        </View>
        :
        <>
          <Text
            style={{
              ...styles.title,
              color: "#000",
              marginTop: 30,
            }}
          >
            {station?.LocationName}
          </Text>
          <Text
            style={{
              ...styles.selecttitle,
              color: "#000",
              marginTop: 8,
            }}
          >
            Select Your Wash:
          </Text>
          {matchedLocation?.StationServices == null || matchedLocation?.StationServices?.length == 0 ?
            <Text style={styles.notfoundText}>
              No wash plans found!
            </Text>
            :
            <View style={{ marginBottom: 60 }}>
              {
                matchedLocation?.StationServices?.map((item) => {
                  return (
                    <TouchableOpacity onPress={() => { setSelectedType(item?.StationServiceName), selectedPlanAnalytics(item) }} style={{ ...styles.ultimateContainer, backgroundColor: selectedType == item?.StationServiceName ? '#00BCFF' : 'white' }} >
                      <Text style={{ ...styles.titleultimate, color: selectedType == item?.StationServiceName ? 'white' : 'black' }} >{item?.StationServiceName}</Text>
                      <Text style={{ ...styles.chargeultimate, color: selectedType == item?.StationServiceName ? 'white' : 'black' }}>{item?.StationServiceDescription}</Text>
                      <Text style={{ ...styles.chargeultimate, color: selectedType == item?.StationServiceName ? 'white' : 'black' }}>${item?.StationServicePrice} UPCHARGE</Text>
                    </TouchableOpacity>
                  )
                })
              }
            </View>
          }
        </>
      }
    </ScrollView>
  );
}
