import { AppInitObserver } from '../../../shared/observers/app-init.observer';


export default new AppInitObserver()