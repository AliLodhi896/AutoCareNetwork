import { NotificationsObserver as NotificationOb } from '../../../shared/observers/notifications.observer';
export const NotificationsObserver = NotificationOb
export default new NotificationsObserver()
