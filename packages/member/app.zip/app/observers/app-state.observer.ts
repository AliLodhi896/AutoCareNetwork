import { AppStateObserver } from '../../../shared/observers/app-state.observer';


export default new AppStateObserver()
