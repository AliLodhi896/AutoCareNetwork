import { Api } from "../../../../shared/services/api"

const WashubClient = new Api()

export default WashubClient